import React from 'react';
import './RegistrationForm.css'; 

const RegistrationForm = () => {
  return (
    <div className="form-container">
      <img src="path/to/logo.png" alt="Logo" className="logo" />
      <h2>Welcome</h2>
      <p>Sign up to Discogs to continue</p>
      <form className="registration-form">
        <div className="form-group">
          <label>Username</label>
          <input type="text" placeholder="Username" className="valid-input" />
        </div>
        <div className="form-group">
          <label>Email address</label>
          <input type="email" placeholder="Email address" className="invalid-input" />
          <p className="error-text">The username or email you entered is already in use. Please try another one.</p>
        </div>
        <div className="form-group">
          <label>Password</label>
          <input type="password" placeholder="Password" />
        </div>
        <button type="submit" className="register-btn">Continue</button>
        <p>Already have an account? <a href="#">Log in</a></p>
      </form>
    </div>
  );
};

export default RegistrationForm;
